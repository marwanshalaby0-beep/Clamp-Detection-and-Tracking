# Clamp detection and counting > clamp-detection-and-counting
https://universe.roboflow.com/clamp-counting-and-detection/clamp-detection-and-counting

Provided by a Roboflow user
License: CC BY 4.0

